/*
 * pid_controller.h
 *
 *  Created on: Jan 7, 2025
 *      Author: lxmit
 */

#ifndef INC_PID_CONTROLLER_H_
#define INC_PID_CONTROLLER_H_



#endif /* INC_PID_CONTROLLER_H_ */

#include "stdint.h"

typedef struct{
	uint16_t Kp;
	uint16_t Kd;
	uint16_t Ki;
    uint16_t max_integral;
    uint16_t max_output;
    uint16_t min_output;

	float prev_err;
	float integral_error;
}pid_struct;

void set_gains(pid_struct* pid ,uint16_t Kp, uint16_t Kd, uint16_t Ki);
void set_limits(pid_struct* pid, uint16_t max_int, uint16_t max_out, uint16_t min_out);
float pid_action(pid_struct* pid, float error, float Ts);
