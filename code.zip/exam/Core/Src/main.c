/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "pid_controller.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
volatile float Sensor_Temp;
volatile int Extern_Temp;
volatile int Initial_Temp;
uint8_t start;
uint8_t isRead;
volatile int ref_value;
pid_struct pid_peltier;
uint32_t ccrP;
uint32_t arrP;
float error;
float outputP;
float dutyP;
const uint8_t Lcd_Address= 0x4E;
const uint8_t RS_BIT= 0;
const uint8_t EN_BIT= 2;
const uint8_t BL_BIT= 3;
const uint8_t D4_BIT= 4;
char num[4];
char numI[4];
char numD[3];
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
uint8_t Sensor_Init(UART_HandleTypeDef*);
uint8_t Sensor_ReadBit(UART_HandleTypeDef*);
uint8_t Sensor_ReadByte(UART_HandleTypeDef*);
void Sensor_WriteByte(UART_HandleTypeDef*, uint8_t);
float Sensor_ReadTemp(UART_HandleTypeDef*);
void Lcd_Init(void);
void delay_time(uint16_t);
void Lcd_Send_Cmd (char);
void Lcd_Send_Data (char);
void Lcd_Send_String (char *);
void Lcd_Put_Cur(uint8_t , uint8_t );
void Lcd_write (uint8_t,uint8_t);
void intToStr(int, char *);
//void Uart_Init(uint32_t baud);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void delay_time(uint16_t time)
{
	uint32_t i;
  	for (i = 0; i < 1000*time; i++) {
		asm("nop");
	}
}

void intToStr(int N, char *str)
{
	uint8_t i =0;
	int temp = N;
	if (N==0){str[i++]='0';}
	else{
		while (N > 0)
		{
			str[i++] = (char) N % 10 + '0';
			N /= 10;
		}

		if (temp < 0) {
			str[i++] = '-';
		}

		for (int j = 0, k = i - 1; j < k; j++, k--)
		{
			char temp = str[j];
			str[j] = str[k];
			str[k] = temp;
		}
	}
	str[i++] = '\0';
}

uint8_t Sensor_Init(UART_HandleTypeDef *huart)
{
    const uint8_t ResetByte = 0xF0;
    uint8_t PresenceByte;
//    Uart_Init(9600);
    huart->Instance->BRR = UART_BRR_SAMPLING16(HAL_RCC_GetPCLK2Freq(), 9600);
    // Mantenere la linea bassa per almeno 480 us (0xF0)
    HAL_UART_Transmit(huart, &ResetByte, 1, 1);
    // Risposta del sensore
    HAL_UART_Receive(huart, &PresenceByte, 1, 1);
    huart->Instance->BRR = UART_BRR_SAMPLING16(HAL_RCC_GetPCLK2Freq(), 115200);
//    Uart_Init(115200);
    if (PresenceByte != ResetByte){
        return 1; // Presence pulse detected
    }
    else{
        return 0; // No presence pulse detected
    }
}

uint8_t Sensor_ReadBit(UART_HandleTypeDef *huart)
{
    const uint8_t ReadBitCMD = 0xFF;
    uint8_t RxBit;

    // Manda sempre 1
    HAL_UART_Transmit(huart, &ReadBitCMD, 1,1);
    // Ricevi
    HAL_UART_Receive(huart, &RxBit, 1 , 1);

    return (RxBit & 0x01);
}

uint8_t Sensor_ReadByte(UART_HandleTypeDef *huart)
{
    uint8_t RxByte = 0;
    for (uint8_t i = 0; i < 8; i++)
    {
        RxByte >>= 1;
        if (Sensor_ReadBit(huart))
        {
            RxByte |= 0x80;
        }
    }
    return RxByte;
}

/*uint8_t Sensor_ReadByte(void)
{
	uint8_t RxBuffer[8];
	uint8_t HighBuffer[8];
    uint8_t RxByte = 0;
    for (uint8_t i = 0; i < 8; i++)
    {
    	HighBuffer[i]=0xFF;
    }
    HAL_UART_Transmit_IT(&huart1, HighBuffer, 8);
    HAL_UART_Receive(&huart1, &RxByte, 1,10);
    while (isRead==0){};
    for (uint8_t i = 0; i < 8; i++)
    {
    	if(RxBuffer[i] == 0xFF)
    	{
    		RxByte = (1<<i);
    	}
    }
    isRead=0;
    return RxByte;
}*/

/*uint8_t Sensor_ReadByte(void)
{
	uint8_t RxBuffer[8];
	uint8_t HighBuffer[8];
    uint8_t RxByte = 0;
    for (uint8_t i = 0; i < 8; i++)
    {
    	HighBuffer[i]=0xFF;
    }
	HAL_UART_Transmit_DMA(&huart1, HighBuffer, 8);
	HAL_UART_Receive_DMA(&huart1, RxBuffer, 8);
    while (isRead==0){};
    for (uint8_t i = 0; i < 8; i++)
    {
    	if(RxBuffer[i] == 0xFF)
    	{
    		RxByte = (1<<i);
    	}
    }
    isRead=0;
    return RxByte;
}*/


void Sensor_WriteByte(UART_HandleTypeDef *huart, uint8_t data)
{
    uint8_t TxBuffer[8];
    for (int i=0; i<8; i++)
    {
      if ((data & (1<<i)) != 0){
          TxBuffer[i] = 0xFF;
      }
      else{
          TxBuffer[i] = 0;
      }
    }
    HAL_UART_Transmit(huart, TxBuffer, 8 , 2);
}

float Sensor_ReadTemp(UART_HandleTypeDef *huart)
{
    uint8_t Temp_LSB, Temp_MSB;
    uint16_t Temp;
    float Temperature;

    Sensor_Init(huart);
    Sensor_WriteByte(huart,0xCC);  // Skip ROM
    Sensor_WriteByte(huart,0xBE);  // Lettura memoria sensore
    Temp_LSB = Sensor_ReadByte(huart);
    Temp_MSB = Sensor_ReadByte(huart);
    Temp = ((Temp_MSB<<8))|Temp_LSB;
    Temperature = (float)Temp/16;

    return Temperature;
}

void Lcd_Init(void){
	delay_time(2880);  // Fermo per 16 ms
//	HAL_Delay(50);
	Lcd_write(0x03, 0);
	delay_time(900);  // Fermo per 5 ms
//	HAL_Delay(5);
	Lcd_write(0x03, 0);
	delay_time(180);  // wait for 1 ms
//	HAL_Delay(1);
	Lcd_write(0x03, 0);
	delay_time(180);
//	HAL_Delay(1);
	Lcd_write(0x02, 0);  // 4bit mode
//	delay_time(1800);

  // dislay initialisation
//	delay_time(180);
//	HAL_Delay(1);
	Lcd_Send_Cmd (0x0C); //display on N=1,F=1
//	delay_time(180);
//	HAL_Delay(1);
	Lcd_Send_Cmd (0x06);  // entry mode
//	delay_time(180);
//	HAL_Delay(1);
	Lcd_Send_Cmd (0x01); //Clear
//	delay_time(180);
//	HAL_Delay(1);
//	HAL_Delay(2);
	delay_time(360);
//	Lcd_Send_Cmd (0x0C); //Display on/off control --> D = 1, C and B = 0. (Cursor and blink, last two bits)
}

void Lcd_write(uint8_t value, uint8_t rs) {
  uint8_t data = value << D4_BIT;
  data |= rs << RS_BIT;
  data |= 1 << BL_BIT;
  data |= 1 << EN_BIT;
  HAL_I2C_Master_Transmit(&hi2c1, Lcd_Address, &data, 1, 100);
  HAL_Delay(1);
  data &= ~(1 << EN_BIT);
  HAL_I2C_Master_Transmit(&hi2c1, Lcd_Address, &data, 1, 100);
}

void Lcd_Send_Cmd (char cmd)
{
	  uint8_t upper_nibble = cmd >> 4;
	  uint8_t lower_nibble = cmd & 0x0F;
	  Lcd_write(upper_nibble, 0);
	  Lcd_write(lower_nibble, 0);
}

void Lcd_Send_Data (char data)
{
	  uint8_t upper_nibble = data >> 4;
	  uint8_t lower_nibble = data & 0x0F;
	  Lcd_write(upper_nibble, 1);
	  Lcd_write(lower_nibble, 1);
}

void Lcd_Send_String (char *str)
{
	while (*str)
	{
		Lcd_Send_Data (*str++);
	}
}

void Lcd_Put_Cur(uint8_t row, uint8_t col)
{
    uint8_t address;
    switch (row) {
        case 0:
            address = 0x00;
            break;
        case 1:
            address = 0x40;
            break;
        default:
            address = 0x00;
    }
    address += col;
    Lcd_Send_Cmd(0x80 | address);
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM6_Init();
  MX_USART1_UART_Init();
  MX_ADC1_Init();
  MX_TIM3_Init();
  MX_I2C1_Init();
  MX_USART3_UART_Init();
  /* USER CODE BEGIN 2 */
  arrP = htim3.Instance -> ARR;
  Lcd_Init();
  if (Extern_Temp>45){Error_Handler();}
  Lcd_Put_Cur(0, 0);
  Lcd_Send_String("Goal:");
  Lcd_Put_Cur(1, 0);
  Lcd_Send_String("Temp:");
 // Lcd_Put_Cur(0, 14);
 // Lcd_Send_String(".0");
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);

  Extern_Temp=50;
  while(Extern_Temp>40){
	  Sensor_Init(&huart3);
	  Sensor_WriteByte(&huart3,0xCC);  // Skip ROM
	  Sensor_WriteByte(&huart3,0x44);  // Comincia la conversione in gradi
	  Extern_Temp= (int) Sensor_ReadTemp(&huart3);
  }
  HAL_ADC_Start_IT(&hadc1);
  set_gains(&pid_peltier,18,3.5,2.3);
  set_limits(&pid_peltier,15,100, 0);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  if (start==0)
	  {
		  intToStr(ref_value, num);
		  if (ref_value<10)
		  {
			  Lcd_Put_Cur(0, 5);
			  Lcd_Send_String("0");
			  Lcd_Put_Cur(0, 6);
			  Lcd_Send_String(num);
			  Lcd_Put_Cur(0, 7);
			  Lcd_Send_String(".0");
		  }
		  else
		  {
			  Lcd_Put_Cur(0, 5);
			  Lcd_Send_String(num);
		  }
	  }else
	  {
		 int intpart = (int) Sensor_Temp;
		 float temp =(Sensor_Temp-intpart)*100;
		 int decpart = (int) temp;
		 intToStr(intpart, numI);
		 if (intpart<10)
		 {
			 Lcd_Put_Cur(1, 5);
			 Lcd_Send_String("0");
			 Lcd_Put_Cur(1, 6);
			 Lcd_Send_String(numI);
			 Lcd_Put_Cur(1, 7);
		 }else
		 {
			 Lcd_Put_Cur(1, 5);
			 Lcd_Send_String(numI);
		 }
		 if (intpart<0){Lcd_Put_Cur(1, 8);}
		 else{Lcd_Put_Cur(1,7);}
		 Lcd_Send_String(".");
		 if (decpart==0)
		 {
			 Lcd_Put_Cur(1, 8);
			 Lcd_Send_String("00");
		 }
		 intToStr(decpart, numD);
		 Lcd_Put_Cur(1, 8);
		 Lcd_Send_String(numD);
	  }
	  delay_time(5000);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 180;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if (htim == &htim6)
	{
		if (ref_value>Extern_Temp){Error_Handler();}
		Sensor_Init(&huart1);
		Sensor_WriteByte(&huart1,0xCC);  // Skip ROM
		Sensor_WriteByte(&huart1,0x44);  // Comincia la conversione in gradi
		Sensor_Temp = Sensor_ReadTemp(&huart1); // Temperatura in centigradi
		if (ref_value>Initial_Temp){
			set_gains(&pid_peltier, 21.8, 6.5, 1.8);
			set_limits(&pid_peltier,10,100, 0);
		}
		error = (float) -(ref_value - Sensor_Temp);
		outputP = pid_action(&pid_peltier, error, 1);
		dutyP = (float) outputP/100;
/*		uint32_t*/ccrP =(uint32_t) (1+arrP)*(1-dutyP);
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, ccrP);
		htim3.Instance->EGR = TIM_EGR_UG;
	}
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	if(GPIO_Pin == GPIO_PIN_13)
	{
		start ^=1;
		if (start==0)
		{
//			htim6.Instance -> CR1 &= ~TIM_CR1_CEN;
//          htim6.Instance -> DIER = 0x00000000;
//			htim3.Instance -> CNT = 0x0000;
			htim3.Instance -> CCR1 = 45000;
			htim3.Instance->EGR = TIM_EGR_UG;
//			htim4.Instance-> CCR1 = 0;
//			htim4.Instance -> CNT = 0x0000;
//			htim4.Instance->EGR = TIM_EGR_UG;
//			htim12.Instance -> CNT = 0x0000;
//			htim12.Instance -> CCR2 = 0;
//			htim12.Instance->EGR = TIM_EGR_UG;
			GPIOA -> ODR &= ~(1<<5);
			GPIOC -> ODR &= ~(1<<5);
			GPIOC -> ODR &= ~(1<<8);
			HAL_TIM_Base_Stop_IT(&htim6);
			htim6.Instance -> CNT = 0x0000;
			Extern_Temp=50;
			while(Extern_Temp>40){
				Sensor_Init(&huart3);
				Sensor_WriteByte(&huart3,0xCC);  // Skip ROM
				Sensor_WriteByte(&huart3,0x44);  // Comincia la conversione in gradi
				Extern_Temp= (int) Sensor_ReadTemp(&huart3);
			}
			HAL_ADC_Start_IT(&hadc1);
		}
		else
		{
			Initial_Temp=50;
			while(Initial_Temp>40)
			{
				Sensor_Init(&huart1);
				Sensor_WriteByte(&huart1,0xCC);  // Skip ROM
				Sensor_WriteByte(&huart1,0x44);  // Comincia la conversione in gradi
				Initial_Temp= (int) Sensor_ReadTemp(&huart1);
			}
		    GPIOA -> ODR |= (1<<5);
			HAL_TIM_Base_Start_IT(&htim6);
//			htim4.Instance-> CCR1 = 3600;
//			htim4.Instance->EGR = TIM_EGR_UG;
//			htim12.Instance-> CCR2 = 3600;
//			htim12.Instance->EGR = TIM_EGR_UG;
			GPIOC -> ODR |= (1<<5);
			GPIOC -> ODR |= (1<<8);
		}
	}
}



void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
	if(hadc -> Instance == ADC1)
	{
		if (start == 0)
		{
			ref_value=(int)HAL_ADC_GetValue(hadc)/256 + (Extern_Temp-15); // Il valore di riferimento varia dipende dalla temperatura ambientale
			HAL_ADC_Start_IT(hadc);
		}

	}
}

/*void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if(huart -> Instance  == USART1)
	{
		   isRead = 1;
	}
}*/

/*void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart , uint16_t Size)
{
	if(huart -> Instance  == USART1)
	{
		   isRead = 1;
	}
}*/
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  Lcd_Put_Cur(0, 0);
  Lcd_Send_String("ERROR");
  Lcd_Put_Cur(1, 0);
  Lcd_Send_String("Press RESET");
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
