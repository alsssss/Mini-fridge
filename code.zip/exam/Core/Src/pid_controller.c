#include "pid_controller.h"

void set_gains(pid_struct* pid, uint16_t Kp, uint16_t Kd, uint16_t Ki)
{
	pid -> Kp = Kp;
	pid -> Kd = Kd;
	pid -> Ki = Ki;
}

void set_limits(pid_struct* pid, uint16_t max_int, uint16_t max_out, uint16_t min_out)
{
	pid -> max_integral = max_int;
	pid -> max_output = max_out;
	pid -> min_output = min_out;
}


float pid_action(pid_struct* pid, float error, float Ts)
{

	float output;

	pid -> integral_error +=  error;
	if (pid -> integral_error > pid -> max_integral)
	{
		pid -> integral_error = pid -> max_integral;
	}
	if (pid -> integral_error < - (pid -> max_integral))
	{
		pid -> integral_error = - (pid -> max_integral);
	}
	output = (pid -> Kp*error) + (pid -> Ki * pid -> integral_error * Ts) +
			(pid -> Kd *(error - pid ->prev_err)/Ts);
	if (output > (pid -> max_output))
	{
		output = pid ->max_output;
	}
	if (output < (pid -> min_output))
	{
		output = pid -> min_output;
	}
	pid -> prev_err = error;

	return output;
}
